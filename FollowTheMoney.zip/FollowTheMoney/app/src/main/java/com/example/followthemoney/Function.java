package com.example.followthemoney;

/**
 * The function parameter for the api calls.
 */
public enum Function implements ApiParameter {

    // Time Series functions
    TIME_SERIES_INTRADAY("TIME_SERIES_INTRADAY"),

    // Stock Quotes
    GLOBAL_QUOTE("GLOBAL_QUOTE"),
    BATCH_STOCK_QUOTES("BATCH_STOCK_QUOTES");



    private final String urlParameter;

    Function(String urlParameter) {
        this.urlParameter = urlParameter;
    }

    @Override
    public String getKey() {
        return "function";
    }

    @Override
    public String getValue() {
        return urlParameter;
    }
}

