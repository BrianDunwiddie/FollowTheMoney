package com.example.followthemoney;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// import java.awt.*;



public class MainActivity extends AppCompatActivity implements  AdapterView.OnItemSelectedListener{

    public static final String EXTRA_MESSAGE = "com.example.followthemoney.MESSAGE";
    int NumStocksTracked = 0;
    int MaxStocksToTrack = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String message_part1 = getResources().getString(R.string.welcome_message1);
        String message_part2 = Integer.toString(NumStocksTracked);
        String message_part3 = getResources().getString(R.string.welcome_message2);
        String message4 = getResources().getString(R.string.initial_message);
        String message5a = getResources().getString(R.string.initial_stock_message);
        String message5b = Integer.toString(MaxStocksToTrack);
        String message5c = getResources().getString(R.string.initial_stock_message2);

        setContentView(R.layout.activity_main);

        final TextView helloTextView = (TextView) findViewById(R.id.welcomeNote);
        helloTextView.setText(message_part1 + " " + message_part2 + " " + message_part3);

        final TextView initialTextView = (TextView) findViewById(R.id.initialNote);
        initialTextView.setText(message4);

        final TextView initialStockView = (TextView) findViewById(R.id.stockNote);
        initialStockView.setText(message5a + " " + message5b + " " + message5c);

        Spinner spinner = findViewById(R.id.time_zone_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.time_zone_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
            String text = adapterView.getItemAtPosition(position).toString();
            Toast.makeText(adapterView.getContext(), text, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, BatchStockQuotes.class);
        EditText editText = (EditText) findViewById(R.id.editText);
        String stock_symbol = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, stock_symbol);
        startActivity(intent);
    }

}
